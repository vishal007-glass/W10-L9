
const MY_DB= "TEST_DATABASE"

module.exports = {  MY_DB  };